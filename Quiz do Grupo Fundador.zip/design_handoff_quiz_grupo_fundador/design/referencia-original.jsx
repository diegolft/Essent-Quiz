import React, { useState } from "react";
import {
  ChevronLeft,
  RotateCcw,
  Wallet,
  TrendingUp,
  CircleOff,
  Dumbbell,
  Flame,
  Scale,
  Target,
  Gauge,
  Check,
  MessageCircle,
} from "lucide-react";

/* ============================================================
   DESIGN TOKENS — identidade Essent
   ============================================================ */
const C = {
  void: "#0c0c0e",
  panel: "#17140f",
  panelSoft: "#1c1712",
  border: "#332a20",
  borderSoft: "#241f19",
  orange: "#ff5a2e",
  orangeLight: "#ff7a45",
  orangeDeep: "#c73f1c",
  white: "#ffffff",
  textSecondary: "#c9c9c0",
  textMuted: "#8a857b",
  amber: "#f2c14e",
};

const displayFont = {
  fontFamily:
    "'Helvetica Neue', Arial, sans-serif",
  fontWeight: 800,
  letterSpacing: "-0.02em",
};

/* ============================================================
   CONTEÚDO DO QUIZ
   ============================================================ */
const STEPS = [
  "hero",
  "identificacao",
  "objetivo",
  "afirmacao",
  "perfil",
  "compromisso",
  "captura",
  "confirmacao",
];

const IDENTIFICACAO_OPTS = [
  { id: "sem_plano", label: "Treino sem plano, sem saber se avanço", icon: RotateCcw },
  { id: "sem_sustentar", label: "Já tentei dieta várias vezes e não sustento", icon: Scale },
  { id: "travado", label: "Tenho resultado, mas travei", icon: Gauge },
  { id: "nunca_comecei", label: "Nunca comecei de verdade", icon: CircleOff },
];

const OBJETIVO_OPTS = [
  { id: "emagrecimento", label: "Emagrecimento", icon: Flame },
  { id: "hipertrofia", label: "Hipertrofia", icon: Dumbbell },
  { id: "recomposicao", label: "Recomposição corporal", icon: TrendingUp },
  { id: "performance", label: "Performance / condicionamento", icon: Target },
];

const TEMPO_TREINO_OPTS = [
  "Nunca treinei",
  "Até 6 meses",
  "6 meses a 2 anos",
  "Mais de 2 anos",
];

const TEMPO_DIA_OPTS = ["Até 15 min", "15 a 30 min", "30 a 60 min", "Mais de 1h"];

const LIKERT = [
  { v: 1, label: "Discordo" },
  { v: 2, label: "" },
  { v: 3, label: "Neutro" },
  { v: 4, label: "" },
  { v: 5, label: "Concordo" },
];

const OBJETIVO_COPY = {
  emagrecimento: "emagrecer sem regredir em 3 semanas",
  hipertrofia: "travar de vez a hipertrofia",
  recomposicao: "recompor o corpo com constância",
  performance: "destravar sua performance",
};

/* ============================================================
   PRIMITIVOS DE UI
   ============================================================ */
function ProgressBar({ index, total }) {
  return (
    <div style={{ display: "flex", gap: 4 }}>
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          style={{
            height: 4,
            flex: 1,
            borderRadius: 999,
            background: i <= index ? C.orange : C.borderSoft,
            transition: "background 0.35s ease",
          }}
        />
      ))}
    </div>
  );
}

function TopBar({ stepIndex, totalContentSteps, onBack, showProgress }) {
  return (
    <div style={{ padding: "18px 20px 14px 20px" }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 12,
          marginBottom: showProgress ? 14 : 0,
        }}
      >
        <button
          onClick={onBack}
          disabled={stepIndex === 0}
          aria-label="Voltar"
          style={{
            background: "none",
            border: "none",
            padding: 4,
            cursor: stepIndex === 0 ? "default" : "pointer",
            opacity: stepIndex === 0 ? 0 : 1,
            color: C.textSecondary,
          }}
        >
          <ChevronLeft size={22} />
        </button>
        {showProgress && (
          <>
            <ProgressBar index={stepIndex - 1} total={totalContentSteps} />
            <span
              style={{
                fontSize: 11,
                color: C.textMuted,
                fontWeight: 700,
                minWidth: 30,
                textAlign: "right",
              }}
            >
              {stepIndex}/{totalContentSteps}
            </span>
          </>
        )}
      </div>
    </div>
  );
}

function Eyebrow({ children }) {
  return (
    <div
      style={{
        color: C.orangeLight,
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: "1.5px",
        textTransform: "uppercase",
        marginBottom: 10,
      }}
    >
      {children}
    </div>
  );
}

function Headline({ children, size = 26 }) {
  return (
    <h1
      style={{
        ...displayFont,
        fontSize: size,
        lineHeight: 1.08,
        color: C.white,
        margin: "0 0 12px 0",
        textTransform: "uppercase",
      }}
    >
      {children}
    </h1>
  );
}

function OptionCard({ icon: Icon, label, selected, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        width: "100%",
        display: "flex",
        alignItems: "center",
        gap: 12,
        textAlign: "left",
        padding: "14px 16px",
        borderRadius: 14,
        border: `1.5px solid ${selected ? C.orange : C.border}`,
        background: selected ? "rgba(255,90,46,0.10)" : C.panel,
        marginBottom: 10,
        cursor: "pointer",
        transition: "all 0.15s ease",
      }}
    >
      {Icon && (
        <div
          style={{
            width: 34,
            height: 34,
            borderRadius: 10,
            background: selected ? C.orange : C.panelSoft,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
          }}
        >
          <Icon size={17} color={selected ? "#2b0f04" : C.orangeLight} strokeWidth={2.3} />
        </div>
      )}
      <span
        style={{
          fontSize: 14.5,
          fontWeight: 600,
          color: selected ? C.white : C.textSecondary,
          lineHeight: 1.3,
        }}
      >
        {label}
      </span>
      {selected && (
        <div style={{ marginLeft: "auto", flexShrink: 0 }}>
          <Check size={18} color={C.orange} strokeWidth={3} />
        </div>
      )}
    </button>
  );
}

function Chip({ label, selected, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "10px 14px",
        borderRadius: 10,
        border: `1.5px solid ${selected ? C.orange : C.border}`,
        background: selected ? "rgba(255,90,46,0.10)" : C.panel,
        color: selected ? C.white : C.textSecondary,
        fontSize: 13,
        fontWeight: 600,
        cursor: "pointer",
        marginBottom: 8,
        marginRight: 8,
      }}
    >
      {label}
    </button>
  );
}

function PrimaryButton({ children, onClick, disabled, style }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        width: "100%",
        padding: "16px 20px",
        borderRadius: 999,
        border: "none",
        background: disabled
          ? C.borderSoft
          : `linear-gradient(180deg, ${C.orangeLight} 0%, ${C.orange} 100%)`,
        color: disabled ? C.textMuted : "#2b0f04",
        fontSize: 15,
        fontWeight: 800,
        cursor: disabled ? "default" : "pointer",
        boxShadow: disabled ? "none" : "0 8px 24px rgba(255,90,46,0.35)",
        transition: "all 0.15s ease",
        ...style,
      }}
    >
      {children}
    </button>
  );
}

/* ============================================================
   TELAS
   ============================================================ */
function HeroScreen({ onNext }) {
  return (
    <div
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        padding: "0 24px",
        background:
          "radial-gradient(120% 70% at 50% 0%, rgba(255,90,46,0.16) 0%, rgba(12,12,14,0) 60%)",
      }}
    >
      <div
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 6,
          marginBottom: 28,
        }}
      >
        <div style={{ width: 4, height: 18, background: C.orange, borderRadius: 2 }} />
        <span
          style={{
            ...displayFont,
            fontSize: 15,
            letterSpacing: "2px",
            color: C.white,
          }}
        >
          ESSENT
        </span>
      </div>

      <Eyebrow>Grupo fundador · vagas limitadas</Eyebrow>
      <Headline size={30}>
        Seu corpo não muda
        <br />
        no piloto automático.
      </Headline>
      <p style={{ color: C.textSecondary, fontSize: 14.5, lineHeight: 1.55, marginBottom: 32 }}>
        60 segundos pra descobrir se você entra pra primeira turma acompanhada
        de perto pelo método Essent.
      </p>

      <PrimaryButton onClick={onNext}>Começar diagnóstico</PrimaryButton>
      <p
        style={{
          textAlign: "center",
          color: C.textMuted,
          fontSize: 11.5,
          marginTop: 14,
        }}
      >
        Sem cadastro. Direto ao ponto.
      </p>
    </div>
  );
}

function IdentificacaoScreen({ value, onSelect }) {
  return (
    <div style={{ padding: "4px 20px" }}>
      <Eyebrow>Diagnóstico</Eyebrow>
      <Headline>Qual dessas é você hoje?</Headline>
      <p style={{ color: C.textMuted, fontSize: 13.5, marginBottom: 22 }}>
        Sem frescura. Escolhe a que mais pesa.
      </p>
      {IDENTIFICACAO_OPTS.map((opt) => (
        <OptionCard
          key={opt.id}
          icon={opt.icon}
          label={opt.label}
          selected={value === opt.id}
          onClick={() => onSelect(opt.id)}
        />
      ))}
    </div>
  );
}

function ObjetivoScreen({ value, onSelect }) {
  return (
    <div style={{ padding: "4px 20px" }}>
      <Eyebrow>Objetivo</Eyebrow>
      <Headline>Onde você quer chegar?</Headline>
      <p style={{ color: C.textMuted, fontSize: 13.5, marginBottom: 22 }}>
        Escolhe o que pesa mais agora.
      </p>
      {OBJETIVO_OPTS.map((opt) => (
        <OptionCard
          key={opt.id}
          icon={opt.icon}
          label={opt.label}
          selected={value === opt.id}
          onClick={() => onSelect(opt.id)}
        />
      ))}
    </div>
  );
}

function AfirmacaoScreen({ value, onSelect }) {
  return (
    <div style={{ padding: "4px 20px" }}>
      <Eyebrow>Autoavaliação</Eyebrow>
      <h1
        style={{
          ...displayFont,
          fontSize: 22,
          lineHeight: 1.25,
          color: C.white,
          margin: "0 0 8px 0",
          fontStyle: "italic",
        }}
      >
        “Sei o que fazer, mas não
        <br />
        consigo manter consistência.”
      </h1>
      <p style={{ color: C.textMuted, fontSize: 13.5, marginBottom: 28 }}>
        O quanto isso é você?
      </p>

      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
        {LIKERT.map((l) => (
          <button
            key={l.v}
            onClick={() => onSelect(l.v)}
            style={{
              width: 46,
              height: 46,
              borderRadius: "50%",
              border: `2px solid ${value === l.v ? C.orange : C.border}`,
              background: value === l.v ? C.orange : C.panel,
              color: value === l.v ? "#2b0f04" : C.textSecondary,
              fontWeight: 800,
              fontSize: 15,
              cursor: "pointer",
            }}
          >
            {l.v}
          </button>
        ))}
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          fontSize: 10.5,
          color: C.textMuted,
          padding: "0 2px",
        }}
      >
        <span>Discordo totalmente</span>
        <span>Concordo totalmente</span>
      </div>
    </div>
  );
}

function PerfilScreen({ tempoTreino, tempoDia, onSelectTreino, onSelectDia }) {
  return (
    <div style={{ padding: "4px 20px" }}>
      <Eyebrow>Seu ponto de partida</Eyebrow>
      <Headline size={24}>Rotina real, sem forçar.</Headline>

      <p style={{ color: C.white, fontSize: 13.5, fontWeight: 700, margin: "22px 0 10px 0" }}>
        Há quanto tempo treina?
      </p>
      <div style={{ display: "flex", flexWrap: "wrap" }}>
        {TEMPO_TREINO_OPTS.map((o) => (
          <Chip key={o} label={o} selected={tempoTreino === o} onClick={() => onSelectTreino(o)} />
        ))}
      </div>

      <p style={{ color: C.white, fontSize: 13.5, fontWeight: 700, margin: "18px 0 10px 0" }}>
        Quanto tempo por dia consegue dedicar?
      </p>
      <div style={{ display: "flex", flexWrap: "wrap" }}>
        {TEMPO_DIA_OPTS.map((o) => (
          <Chip key={o} label={o} selected={tempoDia === o} onClick={() => onSelectDia(o)} />
        ))}
      </div>
    </div>
  );
}

function CompromissoScreen({ value, onSelect }) {
  return (
    <div style={{ padding: "4px 20px", display: "flex", flexDirection: "column", height: "100%" }}>
      <Eyebrow>Antes de continuar</Eyebrow>
      <Headline size={24}>Isso aqui não é pra todo mundo.</Headline>
      <p style={{ color: C.textSecondary, fontSize: 14, lineHeight: 1.55, marginBottom: 28 }}>
        O grupo fundador pede pelo menos 30 dias seguindo o plano, sem trocar
        de estratégia toda semana. É acompanhamento de verdade, não milagre.
      </p>

      <button
        onClick={() => onSelect("topo")}
        style={{
          width: "100%",
          padding: "16px 20px",
          borderRadius: 14,
          border: `1.5px solid ${value === "topo" ? C.orange : C.border}`,
          background: value === "topo" ? "rgba(255,90,46,0.10)" : C.panel,
          color: C.white,
          fontSize: 14.5,
          fontWeight: 700,
          marginBottom: 10,
          cursor: "pointer",
          textAlign: "left",
        }}
      >
        Topo — quero levar a sério
      </button>
      <button
        onClick={() => onSelect("nao")}
        style={{
          width: "100%",
          padding: "16px 20px",
          borderRadius: 14,
          border: `1.5px solid ${value === "nao" ? C.orange : C.border}`,
          background: value === "nao" ? "rgba(255,90,46,0.10)" : C.panel,
          color: C.textSecondary,
          fontSize: 14.5,
          fontWeight: 700,
          cursor: "pointer",
          textAlign: "left",
        }}
      >
        Não é pra mim agora
      </button>
    </div>
  );
}

function CapturaScreen({ nome, whats, onNome, onWhats, objetivo }) {
  const gancho = OBJETIVO_COPY[objetivo] || "destravar seu resultado";
  return (
    <div style={{ padding: "4px 20px" }}>
      <Eyebrow>Quase lá</Eyebrow>
      <Headline size={24}>Você tá dentro do perfil.</Headline>
      <p style={{ color: C.textSecondary, fontSize: 14, lineHeight: 1.5, marginBottom: 24 }}>
        Deixa seu nome e WhatsApp que a gente confirma sua vaga na lista pra{" "}
        {gancho}.
      </p>

      <label style={{ fontSize: 12, color: C.textMuted, fontWeight: 600 }}>Nome</label>
      <input
        value={nome}
        onChange={(e) => onNome(e.target.value)}
        placeholder="Como podemos te chamar"
        style={{
          width: "100%",
          padding: "13px 14px",
          borderRadius: 12,
          border: `1.5px solid ${C.border}`,
          background: C.panel,
          color: C.white,
          fontSize: 14,
          marginTop: 6,
          marginBottom: 16,
          outline: "none",
          boxSizing: "border-box",
        }}
      />

      <label style={{ fontSize: 12, color: C.textMuted, fontWeight: 600 }}>WhatsApp</label>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          border: `1.5px solid ${C.border}`,
          background: C.panel,
          borderRadius: 12,
          padding: "13px 14px",
          marginTop: 6,
        }}
      >
        <MessageCircle size={17} color={C.orangeLight} />
        <input
          value={whats}
          onChange={(e) => onWhats(e.target.value)}
          placeholder="(11) 90000-0000"
          style={{
            border: "none",
            background: "transparent",
            color: C.white,
            fontSize: 14,
            outline: "none",
            flex: 1,
          }}
        />
      </div>
      <p style={{ color: C.textMuted, fontSize: 11, marginTop: 12 }}>
        Vagas limitadas — sem spam, prometo.
      </p>
    </div>
  );
}

function ConfirmacaoScreen({ nome, objetivo }) {
  const primeiro = (nome || "").trim().split(" ")[0] || "Fera";
  const gancho = OBJETIVO_COPY[objetivo] || "destravar seu resultado";
  return (
    <div
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        padding: "0 24px",
        background:
          "radial-gradient(120% 70% at 50% 0%, rgba(255,90,46,0.16) 0%, rgba(12,12,14,0) 60%)",
      }}
    >
      <div
        style={{
          width: 56,
          height: 56,
          borderRadius: "50%",
          background: C.orange,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 20,
        }}
      >
        <Check size={28} color="#2b0f04" strokeWidth={3} />
      </div>
      <Eyebrow>Vaga reservada</Eyebrow>
      <Headline size={26}>
        Fechado, {primeiro}.
        <br />
        Você tá na lista.
      </Headline>
      <p style={{ color: C.textSecondary, fontSize: 14, lineHeight: 1.55, marginBottom: 24 }}>
        Baseado no que você respondeu, separamos sua vaga pro grupo fundador
        focado em {gancho}. A gente te chama no WhatsApp assim que as vagas da
        turma abrirem.
      </p>
      <div
        style={{
          border: `1px solid ${C.border}`,
          background: C.panel,
          borderRadius: 14,
          padding: "14px 16px",
        }}
      >
        <p style={{ color: C.orangeLight, fontSize: 11, fontWeight: 700, textTransform: "uppercase", margin: 0, marginBottom: 6 }}>
          Próximo passo
        </p>
        <p style={{ color: C.textSecondary, fontSize: 13, margin: 0, lineHeight: 1.5 }}>
          Fica de olho no WhatsApp — é por lá que vamos confirmar sua vaga e
          mandar os primeiros conteúdos.
        </p>
      </div>
    </div>
  );
}

/* ============================================================
   APP
   ============================================================ */
export default function EssentQuizPrototype() {
  const [stepIndex, setStepIndex] = useState(0);
  const [answers, setAnswers] = useState({
    identificacao: null,
    objetivo: null,
    afirmacao: null,
    tempoTreino: null,
    tempoDia: null,
    compromisso: null,
    nome: "",
    whats: "",
  });

  const step = STEPS[stepIndex];
  const contentSteps = STEPS.length - 2; // exclui hero e confirmacao
  const contentIndex = stepIndex; // hero=0 -> barra some; steps 1..6 mostram 1..6

  const set = (key) => (val) => setAnswers((a) => ({ ...a, [key]: val }));

  const goNext = () => setStepIndex((i) => Math.min(i + 1, STEPS.length - 1));
  const goBack = () => setStepIndex((i) => Math.max(i - 1, 0));

  const canAdvance = () => {
    switch (step) {
      case "identificacao":
        return !!answers.identificacao;
      case "objetivo":
        return !!answers.objetivo;
      case "afirmacao":
        return !!answers.afirmacao;
      case "perfil":
        return !!answers.tempoTreino && !!answers.tempoDia;
      case "compromisso":
        return !!answers.compromisso;
      case "captura":
        return answers.nome.trim().length > 1 && answers.whats.trim().length > 7;
      default:
        return true;
    }
  };

  const ctaLabel = () => {
    switch (step) {
      case "compromisso":
        return "Continuar";
      case "captura":
        return "Quero minha vaga";
      default:
        return "Continuar";
    }
  };

  const showTopBar = step !== "hero" && step !== "confirmacao";
  const showBottomCta = step !== "hero" && step !== "confirmacao";

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#050506",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "32px 12px",
        fontFamily: "'Helvetica Neue', Arial, sans-serif",
      }}
    >
      {/* PHONE FRAME */}
      <div
        style={{
          width: 380,
          height: 780,
          background: C.void,
          borderRadius: 40,
          border: "8px solid #1a1a1a",
          boxShadow: "0 30px 80px rgba(0,0,0,0.6)",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          position: "relative",
        }}
      >
        {showTopBar && (
          <TopBar
            stepIndex={stepIndex}
            totalContentSteps={contentSteps}
            onBack={goBack}
            showProgress={true}
          />
        )}

        <div
          style={{
            flex: 1,
            overflowY: "auto",
            display: "flex",
            flexDirection: "column",
          }}
          key={step}
        >
          {step === "hero" && <HeroScreen onNext={goNext} />}
          {step === "identificacao" && (
            <IdentificacaoScreen value={answers.identificacao} onSelect={set("identificacao")} />
          )}
          {step === "objetivo" && (
            <ObjetivoScreen value={answers.objetivo} onSelect={set("objetivo")} />
          )}
          {step === "afirmacao" && (
            <AfirmacaoScreen value={answers.afirmacao} onSelect={set("afirmacao")} />
          )}
          {step === "perfil" && (
            <PerfilScreen
              tempoTreino={answers.tempoTreino}
              tempoDia={answers.tempoDia}
              onSelectTreino={set("tempoTreino")}
              onSelectDia={set("tempoDia")}
            />
          )}
          {step === "compromisso" && (
            <CompromissoScreen value={answers.compromisso} onSelect={set("compromisso")} />
          )}
          {step === "captura" && (
            <CapturaScreen
              nome={answers.nome}
              whats={answers.whats}
              onNome={set("nome")}
              onWhats={set("whats")}
              objetivo={answers.objetivo}
            />
          )}
          {step === "confirmacao" && (
            <ConfirmacaoScreen nome={answers.nome} objetivo={answers.objetivo} />
          )}
        </div>

        {showBottomCta && (
          <div style={{ padding: "14px 20px 22px 20px" }}>
            <PrimaryButton disabled={!canAdvance()} onClick={goNext}>
              {ctaLabel()}
            </PrimaryButton>
          </div>
        )}
      </div>
    </div>
  );
}
