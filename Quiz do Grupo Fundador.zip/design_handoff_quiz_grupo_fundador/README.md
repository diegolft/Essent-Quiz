# Handoff: Quiz do Grupo Fundador (Essent)

## Visão geral

Quiz de diagnóstico de 9 telas usado como isca do funil de captação do Grupo Fundador — ciclo concierge pré-lançamento do app Essent. O usuário chega de um reel no Instagram, responde 6 passos de conteúdo, passa por uma tela de análise animada e deixa nome + WhatsApp. A confirmação personaliza a copy com base no objetivo escolhido.

Há um desvio: quem recusa o compromisso de 30 dias vai para uma tela de atrito e, de lá, pode voltar ao fluxo principal ou entrar numa lista de espera geral (captura e confirmação com copy própria, sem promessa de vaga).

## Sobre os arquivos deste pacote

Os arquivos em `design/` são **referências de design feitas em HTML** — protótipos que mostram aparência e comportamento pretendidos, não código de produção para copiar direto. A tarefa é **recriar esses designs no ambiente do codebase de destino** (React, React Native, Vue, SwiftUI, nativo, etc.), usando os padrões e bibliotecas já estabelecidos lá. Se ainda não existe ambiente, escolha o framework mais adequado ao projeto e implemente ali.

`design/Essent Quiz.dc.html` é o design canônico e atual. Ele usa um runtime de streaming próprio (`support.js`) — abra o arquivo num navegador com os três arquivos na mesma pasta para ver o protótipo rodando. Leia o HTML como especificação: toda a estrutura está no template no topo e toda a lógica na classe `Component` embaixo.

`design/referencia-original.jsx` é o protótipo React original (anterior). Está aqui apenas como histórico — onde ele divergir do `.dc.html`, o `.dc.html` vence.

## Fidelidade

**Alta fidelidade (hifi).** Cores, tipografia, espaçamentos, estados e animações são finais. Recrie a UI com precisão, usando as bibliotecas do codebase. As únicas peças abertas são as fotos das opções de Objetivo (ver Assets).

## Layout base

- Viewport alvo: mobile, 390 × 810 px (o protótipo tem um toggle Moldura / Tela cheia que é **apenas ferramenta de apresentação** — não implemente).
- Estrutura fixa em coluna: barra de topo (fixa) → área de conteúdo (rolável, `flex: 1`) → barra de CTA (fixa).
- Fundo do app: `#0c0c0e`.
- Conteúdo das telas de passo é **centralizado verticalmente** via `margin: auto 0` num wrapper interno (não `justify-content: center`, para não cortar conteúdo alto em telas pequenas).
- Padding lateral: 20px nas telas de passo, 24px nas telas de momento (hero, análise, confirmação).

## Design tokens

### Cores base

| Token | Hex | Uso |
| --- | --- | --- |
| void | `#0c0c0e` | fundo do app |
| panel | `#17140f` | fundo de cards, inputs, chips |
| panelSoft | `#1c1712` | fundo de chip de ícone |
| border | `#332a20` | borda padrão |
| borderSoft | `#241f19` | trilhas de progresso, CTA desabilitado |
| white | `#ffffff` | headlines, labels selecionados |
| textSecondary | `#c9c9c0` | corpo de texto |
| textMuted | `#8a857b` | legendas, hints, texto desabilitado |
| onOrange | `#2b0f04` | texto/ícone sobre laranja |
| ink | `#0e1214` | texto/ícone sobre as cores da paleta |
| stage | `#050506` | fundo fora do app (só apresentação) |

### Marca

| Token | Hex |
| --- | --- |
| orange | `#ff5a2e` |
| orangeLight | `#ff7a45` |

Laranja é exclusivo da marca: logo, CTA primário, hero, gate de compromisso, confirmação de vaga.

### Paleta de apoio

| Token | Hex |
| --- | --- |
| amber | `#f7b32b` |
| mint | `#35d6a4` |
| cyan | `#38bdf8` |
| violet | `#a78bfa` |
| pink | `#f472b6` |

Regra de uso: cada cor é atribuída a um item específico (uma opção, um passo, um grupo de chips) e se repete de forma consistente. Fundo tintado de item selecionado = a cor a 9–10% de opacidade; borda = a cor cheia.

### Tipografia

- Headlines: **Barlow Condensed** 800, caixa alta, `line-height: 1.02`, `letter-spacing: -0.005em` no hero.
- Corpo e UI: **Barlow** 400/500/600/700.
- Pull quote (tela 4): Barlow *italic* 500, 22px, caixa normal — é a única headline não condensada e não em caixa alta.

| Elemento | Fonte | Tamanho | Peso |
| --- | --- | --- | --- |
| Headline hero | Barlow Condensed | 42px | 800 |
| Headline confirmação | Barlow Condensed | 38px | 800 |
| Headline de passo | Barlow Condensed | 32px | 800 |
| Contador de análise | Barlow Condensed | 44px | 800 |
| Logo ESSENT | Barlow Condensed | 17px / `letter-spacing: 0.18em` | 800 |
| Eyebrow | Barlow | 11px / `letter-spacing: 0.15em` / uppercase | 700 |
| Corpo | Barlow | 14–14.5px / `line-height: 1.55` | 400 |
| Label de opção | Barlow | 14.5–15px | 600–700 |
| Hint de card, legendas | Barlow | 11–13.5px | 600 |
| Texto do CTA | Barlow | 15px | 800 |
| Número Likert | Barlow Condensed | 19px | 800 |

### Raios e sombras

| Uso | Valor |
| --- | --- |
| Botão CTA, chips do toggle | `999px` (pill) |
| Cards de opção, botões do gate, box "Próximo passo" | `14px` |
| Input, chip de ícone, slot de imagem | `10–12px` |
| Círculo Likert, badge de confirmação | `50%` |
| Sombra do CTA | `0 10px 30px rgba(255,90,46,0.32)` |
| Sombra do Likert selecionado | `0 6px 20px <cor a 35%>` |

### Gradientes

- CTA primário: `linear-gradient(180deg, #ff7a45 0%, #ff5a2e 100%)`, texto `#2b0f04`.
- Glow do hero e da confirmação: `radial-gradient(120% 62% at 50% 0%, rgba(255,90,46,0.20) 0%, rgba(12,12,14,0) 62%)`. **Só nessas duas telas.**
- Glow da confirmação de lista de espera: mesmo formato, com `rgba(56,189,248,0.10)`.
- Barra e filete multicolor: `linear-gradient(90deg, #ff5a2e, #f7b32b, #35d6a4, #38bdf8, #a78bfa)`.
- Halo da análise: `conic-gradient(from 0deg, #ff5a2e, #f7b32b, #35d6a4, #38bdf8, #a78bfa, #f472b6, #ff5a2e)`.

### Ícones

Phosphor Icons, peso **duotone**, em todas as telas. Nomes usados: `caret-left`, `arrow-counter-clockwise`, `scales`, `gauge`, `prohibit`, `flame`, `barbell`, `trend-up`, `target`, `check`, `fire-simple`, `hourglass-medium`, `calendar-dots`, `timer`, `whatsapp-logo`, `warning-circle`, `bell`.

## Barra de topo

Visível em todas as telas exceto hero, análise e confirmação. Padding `18px 20px 14px`.

- Seta de voltar: `caret-left` 21px, cor `#c9c9c0`, sem fundo.
- Progresso: 6 segmentos de `height: 4px`, `flex: 1`, gap 4px, raio 999px. Segmento preenchido usa **a cor daquele passo**, na ordem: `#ff5a2e`, `#f7b32b`, `#35d6a4`, `#38bdf8`, `#a78bfa`, `#f472b6`. Não preenchido: `#241f19`. Transição `background .4s ease`.
- Contador à direita: `N/6`, 11px, peso 700, `#8a857b`.

O progresso conta **6 passos de conteúdo**: identificação 1, objetivo 2, afirmação 3, perfil 4, compromisso 5, captura 6. A tela de atrito mantém o contador em 5. Hero, análise e confirmação não têm barra.

## Barra de CTA

Visível em todas as telas exceto hero, análise, atrito e confirmação. Padding `14px 20px 22px`.

Botão largura total, pill, padding `17px 20px`, 15px/800.
- Habilitado: gradiente laranja, texto `#2b0f04`, sombra laranja. Hover `translateY(-1px)`, active `translateY(1px)`.
- Desabilitado: fundo `#241f19`, texto `#8a857b`, sem sombra, cursor default.

Rótulos: "Continuar" em tudo, "Quero minha vaga" na captura (fluxo fundador), "Entrar na lista de espera" na captura (fluxo espera).

## Telas

Toda a copy abaixo é literal — use exatamente como está.

### 1. Hero

Centralizada, glow laranja no topo. Sem barra de topo, sem barra de CTA (o botão é parte do conteúdo).

- Logo: barra vertical 4×19px `#ff5a2e` raio 2px + "ESSENT". Margem inferior 30px.
- Eyebrow `#ff7a45`: "Grupo fundador · vagas limitadas"
- Headline 42px: "Seu corpo não muda no piloto automático."
- Corpo: "60 segundos pra descobrir se você entra pra primeira turma acompanhada de perto pelo método Essent."
- Linha de escassez, 11.5px uppercase `#8a857b`, itens separados por um ponto de 3px `#4a443c`: "50 vagas" · "7 dias de inscrição" (números configuráveis).
- CTA: "Começar diagnóstico"
- Rodapé 11.5px centralizado: "Sem cadastro. Direto ao ponto."

### 2. Identificação — passo 1

Single-select, 4 cards com ícone + frase em 1ª pessoa.

- Eyebrow: "Diagnóstico" · Headline: "Qual dessas é você hoje?" · Sub: "Sem frescura. Escolhe a que mais pesa."
- Card: largura total, flex row, gap 12px, padding `14px 16px`, raio 14px, borda 1.5px, gap 10px entre cards.
  - Chip de ícone 34×34, raio 10px. Não selecionado: fundo = cor do item a 14%, ícone na cor do item. Selecionado: fundo = cor cheia, ícone `#0e1214`.
  - Label 14.5px/600, `#c9c9c0` → `#ffffff` quando selecionado.
  - Check 18px na cor do item, à direita, com animação `popIn` 0.2s.
  - Borda `#332a20` → cor do item; fundo `#17140f` → cor do item a 9%.

| Opção | id | Ícone | Cor |
| --- | --- | --- | --- |
| Treino sem plano, sem saber se avanço | `sem_plano` | `arrow-counter-clockwise` | cyan |
| Já tentei dieta várias vezes e não sustento | `sem_sustentar` | `scales` | violet |
| Tenho resultado, mas travei | `travado` | `gauge` | amber |
| Nunca comecei de verdade | `nunca_comecei` | `prohibit` | pink |

### 3. Objetivo — passo 2

Single-select, 4 cards com **foto** + título + hint.

- Eyebrow: "Objetivo" · Headline: "Onde você quer chegar?" · Sub: "Escolhe o que pesa mais agora."
- Card: flex row, gap 13px, padding `10px 14px 10px 10px`, raio 14px, borda 1.5px, mesmos estados de cor do passo 1.
  - Foto 76×76, raio 10px, `object-fit: cover`. Não selecionada: `filter: saturate(0.5) brightness(0.82)`; selecionada: `filter: none`. Transição `.2s`.
  - Título 15px/700. Abaixo, linha com ícone 14px na cor do item + hint 11.5px `#8a857b`.
  - Check 18px na cor do item.
  - O card inteiro é o alvo de seleção (`role="button"`, `tabindex="0"`, Enter/Espaço selecionam). No protótipo o clique na foto é interceptado apenas para permitir a troca da imagem — no app, o clique na foto deve selecionar a opção como o resto do card.

| Opção | id | Hint | Ícone | Cor | Foto |
| --- | --- | --- | --- | --- | --- |
| Emagrecimento | `emagrecimento` | Perder peso e manter | `flame` | orange | pessoa insatisfeita com o peso |
| Hipertrofia | `hipertrofia` | Ganhar massa | `barbell` | cyan | pessoa treinando com peso |
| Recomposição corporal | `recomposicao` | Trocar gordura por músculo | `trend-up` | mint | corpo em transformação |
| Performance / condicionamento | `performance` | Render e durar mais | `target` | violet | corredor |

### 4. Afirmação — passo 3

Escala Likert 1–5.

- Eyebrow: "Autoavaliação"
- Filete vertical 2px à esquerda da citação, com `linear-gradient(180deg, #f472b6 0%, #38bdf8 50%, #f7b32b 100%)`, gap 14px.
- Citação (Barlow italic 500, 22px, `line-height: 1.3`): “Sei o que fazer, mas não consigo manter consistência.”
- Sub, recuado 22px: "O quanto isso é você?" — margem inferior 30px.
- 5 círculos, `flex: 1`, `aspect-ratio: 1`, gap 6px, borda 2px. Não selecionado: fundo `#17140f`, borda `#332a20`, número `#c9c9c0`. Selecionado: fundo = cor cheia, número `#0e1214`, `scale(1.06)`, sombra na cor a 35%.
- Cores por valor: 1 pink, 2 violet, 3 cyan, 4 mint, 5 amber.
- Legendas 10.5px `#8a857b` nas pontas: "Discordo totalmente" / "Concordo totalmente".

### 5. Perfil — passo 4

Dois grupos de chips na mesma tela. Ambos obrigatórios.

- Eyebrow: "Seu ponto de partida" · Headline: "Rotina real, sem forçar."
- Rótulo de grupo: 13.5px/700 branco, com ícone 17px à esquerda. Grupo 1: `calendar-dots` cyan, "Há quanto tempo treina?" — opções: Nunca treinei / Até 6 meses / 6 meses a 2 anos / Mais de 2 anos. Grupo 2: `timer` violet, "Quanto tempo por dia consegue dedicar?" — opções: Até 15 min / 15 a 30 min / 30 a 60 min / Mais de 1h.
- Chip: padding `10px 14px`, raio 10px, 13px/600, borda 1.5px, wrap com gap 8px. Selecionado: borda = cor do grupo, fundo = cor a 10%, texto branco. Clicar no chip selecionado desmarca.

### 6. Compromisso — passo 5

Gate binário. Dois botões grandes; sem auto-seleção prévia.

- Eyebrow: "Antes de continuar" · Headline: "Isso aqui não é pra todo mundo."
- Corpo: "O grupo fundador pede pelo menos 30 dias seguindo o plano, sem trocar de estratégia toda semana. É acompanhamento de verdade, não milagre."
- Botões: largura total, padding `18px 20px`, raio 14px, 14.5px/700, texto à esquerda, ícone 20px + gap 11px.
  - "Topo — quero levar a sério" — ícone `fire-simple` `#ff7a45`, texto branco → vai para a análise.
  - "Não é pra mim agora" — ícone `hourglass-medium` `#8a857b`, texto `#c9c9c0` → vai para o atrito.
  - Selecionado: borda `#ff5a2e`, fundo laranja a 10%.

### 6b. Atrito (desvio)

Só aparece para quem escolheu "Não é pra mim agora". Centralizada. Barra de topo presente (contador em 5), sem barra de CTA.

- Eyebrow `#8a857b`: "Sem pressa"
- Headline: "Então melhor não pegar sua vaga agora."
- Corpo: "O grupo fundador tem 50 vagas e cada uma vira acompanhamento próximo por 30 dias. Sem esse compromisso, a vaga rende mais com outra pessoa — e você não fica com a sensação de ter desperdiçado." (o número vem da config)
- Corpo secundário `#8a857b`: "Se o momento não é esse, entra na lista de espera geral. Você é avisado quando o app abrir pra todo mundo."
- Botão primário (pill laranja): "Pensando bem, eu topo os 30 dias" → grava compromisso = topo e segue para a análise.
- Botão secundário (pill outline, borda `#332a20`, texto `#c9c9c0`; hover borda `#4a4038` e texto branco): "Entrar na lista de espera geral" → entra no modo espera e vai direto para a captura, **sem passar pela análise**.

### 6c. Análise (6 segundos)

Tela de transição automática entre o compromisso e a captura, só no fluxo fundador. Sem barra de topo, sem CTA, sem voltar. Duração total **6000ms**, então navega para a captura.

Composição, de cima para baixo, centralizada:

1. **Halo de fundo**: elipse `left: -30%; top: 6%; width: 160%; height: 46%`, `border-radius: 50%`, `filter: blur(46px)`, `opacity: 0.42`, com o conic-gradient da paleta, girando 360° em 9s linear infinito. `overflow: hidden` no container.
2. **Anéis**: caixa 176×176 com três anéis concêntricos, todos `border: 2px solid rgba(255,255,255,0.05)` e raio 50%:
   - externo (`inset: 0`): `border-top-color` e `border-right-color` = `#38bdf8`, gira +360° em 2.4s linear infinito
   - médio (`inset: 20px`): `border-bottom-color` e `border-left-color` = `#a78bfa`, gira −360° em 3.2s
   - interno (`inset: 40px`): `border-top-color` = `#35d6a4`, gira +360° em 1.8s
   - núcleo (`inset: 58px`): `radial-gradient(circle at 50% 40%, rgba(255,90,46,0.30), transparent 70%)` pulsando (`scale 1 → 1.06`, opacidade `.85 → 1`) em 2.6s ease-in-out infinito
3. **Contador** no centro: percentual 44px Barlow Condensed 800 branco + label 10px uppercase `#8a857b` "Analisado". O percentual vai de 0 a 100 sobre 5600ms (`min(100, round(ms / 5600 * 100))`), atualizado a cada ~60ms.
4. **Títulos** centralizados: eyebrow `#38bdf8` "Análise em curso" + headline 32px "Montando seu perfil."
5. **Lista de 5 etapas**, gap 12px, cada linha com marcador circular 20×20 (borda 2px) + label 13.5px/600:

   | Ordem | Label | Cor |
   | --- | --- | --- |
   | 1 | Cruzando suas respostas | orange |
   | 2 | Lendo seu ponto de partida | amber |
   | 3 | Calibrando volume de treino | mint |
   | 4 | Ajustando o ritmo da dieta | cyan |
   | 5 | Montando sua rota de 30 dias | violet |

   Cada etapa dura `(6000 − 700) / 5 = 1060ms`. Estados do marcador:
   - pendente: borda `#332a20`, fundo transparente, check invisível, linha a `opacity: 0.3`, label `#8a857b`
   - ativa: borda = cor da etapa, fundo transparente, check invisível, linha a `opacity: 1`, label branco, marcador pulsando (`opacity .35→1`, `scale .8→1.15`, 1s ease-in-out infinito)
   - concluída: borda e fundo = cor da etapa, check 11px `#0e1214`, label branco
6. **Barra final**: trilha 4px `#241f19` raio 999px, margem superior 30px, preenchida pelo gradiente multicolor com `width` = percentual e `transition: width .12s linear`.

Se o usuário recarregar a página durante a análise, ele volta para a tela de compromisso (a análise nunca é restaurada pelo meio).

### 7. Captura — passo 6

Copy dinâmica em duas variantes.

**Fluxo fundador:** eyebrow `#ff7a45` "Quase lá" · headline "Você tá dentro do perfil." · corpo "Deixa seu nome e WhatsApp que a gente confirma sua vaga na lista pra {gancho}." · rodapé "Vagas limitadas — sem spam, prometo."

**Fluxo lista de espera:** eyebrow `#8a857b` "Lista de espera" · headline "Te aviso quando abrir." · corpo "Deixa nome e WhatsApp que a gente te chama quando o app abrir pro público geral. Sem vaga de grupo fundador, sem cobrança de compromisso." · rodapé "Um aviso só, quando abrir. Sem spam."

Onde `{gancho}` vem do objetivo escolhido no passo 2:

| Objetivo | Gancho |
| --- | --- |
| emagrecimento | emagrecer sem regredir em 3 semanas |
| hipertrofia | travar de vez a hipertrofia |
| recomposicao | recompor o corpo com constância |
| performance | destravar sua performance |
| (nenhum) | destravar seu resultado |

Campos:
- Label 12px/600 `#8a857b` "Nome"; input largura total, padding 14px, raio 12px, borda 1.5px `#332a20`, fundo `#17140f`, texto branco 14px, placeholder "Como podemos te chamar" em `#6f6a61`. Foco: borda `#38bdf8`.
- Label "WhatsApp"; container flex com ícone `whatsapp-logo` 19px `#35d6a4` + input, placeholder "(11) 90000-0000", `inputmode="tel"`.
- Erro (abaixo do campo): ícone `warning-circle` 14px + "Coloca DDD + número, com 10 ou 11 dígitos." em `#f472b6` 11.5px; borda do container vira `#f472b6`.

### 8. Confirmação

Centralizada, glow. Sem barra de topo, sem CTA.

**Fluxo fundador:** badge 56px redondo laranja com check 28px `#2b0f04` (animação `popIn` 0.38s) · eyebrow `#ff7a45` "Vaga reservada" · headline 38px "Fechado, {primeiro nome}. Você tá na lista." · corpo "Baseado no que você respondeu, separamos sua vaga pro grupo fundador focado em {gancho}. A gente te chama no WhatsApp assim que as vagas da turma abrirem." · box "Próximo passo": "Fica de olho no WhatsApp — é por lá que vamos confirmar sua vaga e mandar os primeiros conteúdos."

**Fluxo lista de espera:** badge com fundo cyan a 16% e ícone `bell` cyan · glow cyan · eyebrow cyan "Você está na fila" · headline "Anotado, {primeiro nome}." · corpo "Você entrou na lista de espera geral. Quando o app abrir pro público, você é um dos primeiros a saber — e o grupo fundador segue de porta aberta se você mudar de ideia antes disso." · box: "Nada a fazer agora. Guarda nosso número no WhatsApp pra não perder o aviso."

Box "Próximo passo": borda 1px `#332a20`, fundo `#17140f`, raio 14px, padding `15px 16px`, com filete vertical de 3px na borda esquerda usando o gradiente multicolor. Kicker 11px uppercase `#ff7a45` "Próximo passo" + corpo 13px `#c9c9c0`.

Botão de reiniciar (centralizado, 22px abaixo): pill outline borda `#241f19`, texto `#8a857b` 12.5px/600, ícone `arrow-counter-clockwise` 14px, label "Refazer diagnóstico". Hover: texto branco, borda `#332a20`. Limpa tudo e volta ao hero.

Fallback do primeiro nome quando vazio: "Fera".

## Interações e comportamento

### Navegação

| De | Ação | Para |
| --- | --- | --- |
| hero | CTA | identificação |
| identificação → objetivo → afirmação → perfil | CTA ou auto-avanço | próximo passo |
| perfil | CTA (só com os dois grupos respondidos) | compromisso |
| compromisso | "Topo" | análise |
| compromisso | "Não é pra mim agora" | atrito |
| atrito | "Pensando bem, eu topo os 30 dias" | análise (modo fundador) |
| atrito | "Entrar na lista de espera geral" | captura (modo espera) |
| análise | automático após 6000ms | captura |
| captura | CTA | confirmação |

Voltar: identificação→hero, objetivo→identificação, afirmação→objetivo, perfil→afirmação, compromisso→perfil, atrito→compromisso, captura→compromisso (fundador) ou atrito (espera). Análise e confirmação não têm voltar.

### Auto-avanço

Selecionar uma opção nas telas de single-select avança automaticamente após **380ms** (tempo de ver o estado selecionado). Vale para identificação, objetivo, afirmação e os dois botões do compromisso. **Não** vale para perfil (dois grupos) nem para a captura. Deve ser desligável por config — o protótipo expõe um flag `autoAdvance`.

### Validação

O CTA fica desabilitado até haver resposta válida:

| Tela | Regra |
| --- | --- |
| identificação / objetivo / afirmação / compromisso | uma opção selecionada |
| perfil | os dois grupos respondidos |
| captura | nome com mais de 1 caractere após trim **e** WhatsApp com 10 ou 11 dígitos |

WhatsApp: máscara aplicada na digitação, no máximo 11 dígitos. Até 10 dígitos → `(XX) XXXX-XXXX`; 11 dígitos → `(XX) XXXXX-XXXX`. O erro só aparece depois do primeiro blur e só se o campo não estiver vazio.

### Transições

- Entrada de tela: `screenIn` — `opacity 0→1` + `translateY(14px→0)`, 340ms `cubic-bezier(.2,.7,.3,1)`. Hero e confirmação usam 380ms.
- Glow do hero/confirmação: fade-in de 1.1s.
- Badge da confirmação e checks: `popIn` — `opacity 0→1` + `scale(.7→1)`, 200ms (badge 380ms com easing `cubic-bezier(.2,.9,.3,1)`).
- Estados de card/chip/input: `all .16s ease` (filtro da foto `.2s`, progresso `.4s`).
- Hover de botão pill: `translateY(-1px)`; active `translateY(1px)`.
- Foco de teclado: `outline: 2px solid #ff7a45; outline-offset: 2px` — nunca o azul padrão do navegador.

## Estado

```
screen: 'hero' | 'identificacao' | 'objetivo' | 'afirmacao' | 'perfil'
      | 'compromisso' | 'atrito' | 'analise' | 'captura' | 'confirmacao'
mode:   'fundador' | 'espera'
answers: {
  identificacao: string | null
  objetivo:      string | null
  afirmacao:     1..5 | null
  tempoTreino:   string | null
  tempoDia:      string | null
  compromisso:   'topo' | 'nao' | null
  nome:          string
  whats:         string   // com máscara
}
whatsTouched: boolean     // controla a exibição do erro
analysisMs:   number      // 0..6000, só durante a análise
```

Persistência: `screen`, `mode` e `answers` são gravados em armazenamento local a cada mudança, sob a chave `essent-quiz-v1`, e restaurados na montagem. Se o `screen` salvo for `analise`, restaure como `compromisso`. "Refazer diagnóstico" apaga a chave.

Timers: um timeout para o auto-avanço e um intervalo de 60ms para a análise. Ambos devem ser limpos em qualquer navegação e na desmontagem.

Backend: o protótipo não envia nada. No app real, o submit da captura deve gravar nome, WhatsApp, todas as respostas e o `mode` (fundador vs. lista de espera) — o `mode` é o que separa as duas audiências no CRM.

## Configuração

Valores expostos como ajustáveis no protótipo, para virarem config/props no app:

| Nome | Default | Uso |
| --- | --- | --- |
| `vagas` | 50 | linha de escassez do hero, corpo do atrito |
| `dias` | 7 | linha de escassez do hero |
| `autoAdvance` | true | liga/desliga o auto-avanço |

## Assets

- **Fotos das 4 opções de Objetivo** — não fornecidas. No protótipo são slots de imagem (`design/image-slot.js`) que o time preenche arrastando arquivos; a imagem fica gravada num sidecar JSON e **não** faz parte do design. No app, use 4 fotos reais em 76×76 (`object-fit: cover`, servidas em 2×/3×) seguindo a descrição na tabela do passo 2.
- **Fontes**: Barlow e Barlow Condensed (Google Fonts, SIL Open Font License).
- **Ícones**: Phosphor Icons, peso duotone (MIT). Se o codebase já tem uma biblioteca de ícones, use a equivalente mais próxima e mantenha o peso duotone se existir.
- **Logo Essent**: reproduzido como barra + wordmark. Substitua pelo asset oficial do app.

## Arquivos

| Arquivo | O que é |
| --- | --- |
| `design/Essent Quiz.dc.html` | design canônico e atual — template no topo, lógica na classe `Component` embaixo |
| `design/support.js` | runtime necessário para abrir o arquivo acima no navegador (não é código de produção) |
| `design/image-slot.js` | componente de placeholder de imagem usado nas opções de Objetivo (não é código de produção) |
| `design/referencia-original.jsx` | protótipo React anterior, mantido como histórico |
